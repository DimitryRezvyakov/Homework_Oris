﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniHttpServer.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class Endpoint : Attribute
    {
        public string Route { get; }
        public Endpoint(string route = null)
        {
            Route = route;
        }
    }
}
